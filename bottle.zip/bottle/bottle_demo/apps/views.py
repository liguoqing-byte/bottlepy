from bottle_plus.bottle_plus import run, route, template, request
from forms import LoginForm
from apps.model import *
import time

'''
@route('/', method=['GET', 'POST'])
def test(db, session, rdb):
    rdb.incr('visitors')
    visitor = rdb.get('visitors')
    last_visit = session['visit']
    session['visit'] = time.time()
    name = db.query(Users).filter_by().first().username
    return 'You are visitor %s, your last visit was on %s  %s' % (visitor, last_visit, name)
    
@route('/test2', method=['GET', 'POST'])
def test2():
    if request.method == 'GET':
        name = db.query(Users).filter_by().first().username
        return '<p>{}</p>'.format(name)


@route('/login', method=['POST','GET'])
def index():
    if request.method == 'POST':
        f = LoginForm(request)
        if f.is_valid():
            print(f.value_dict)
        else:
            print(f.error_dict)

    return template('login.html')
'''








