from Tyrion import Forms as form
from Tyrion.Fields import StringField


class LoginForm(form.Form):
    username = StringField(max_length=20, error={'required': '用户名不能为空'})
