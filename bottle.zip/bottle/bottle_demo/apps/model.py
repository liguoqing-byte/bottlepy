from sqlalchemy import Column, Integer, Sequence, String, Boolean
from global_conf.settings import Base

# Create your models here.


class Users(Base):
    __tablename__ = 'users'
    id = Column(Integer, Sequence('id_seq'), primary_key=True, autoincrement=True)
    username = Column(String(20), unique=True)
    password = Column(String(20))
    img_url = Column(String(200))
    sex = Column(Integer, default=1)
    nickname = Column(String(50))
    is_delete = Column(Boolean, default=False)
    is_superuser = Column(Boolean, default=False)

    def __init__(self, username, password, img_url, sex, nickname, is_delete, is_superuser):
        self.username = username
        self.password = password
        self.img_url = img_url
        self.sex = sex
        self.nickname = nickname
        self.is_delete = is_delete
        self.is_superuser = is_superuser

    def to_json(self):
        dict = self.__dict__
        if "_sa_instance_state" in dict:
            del dict["_sa_instance_state"]
        return dict

    def __repr__(self):
        return "<Students('%s')>" % self.username
