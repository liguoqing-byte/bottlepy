#!/usr/bin/python
# -*- coding: UTF-8 -*-
#!/usr/bin/python
# -*- coding: UTF-8 -*-
from bottle import route, static_file, run, TEMPLATE_PATH
import logging
import os
import sys


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_PATH.append('/'.join((BASE_DIR, 'templates')))


@route('<filename:re:.*\.css|.*\.js|.*\.png|.*\.jpg|.*\.jpeg|.*\.gif|.*\.otf|.*\.eot|.*\.woff|.*\.mp3|.*\.map|.*\.mp4>')
def server_static(filename):
    """定义static下所有的静态资源路径"""
    return static_file(filename, root='static')


import apps

log_path = ('/'.join((BASE_DIR, 'log')))
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S',
                    filename="%s/error_log" % log_path,
                    filemode='a')


HOST = '0.0.0.0'
PORT = sys.argv[1] if len(sys.argv) > 1 else '8080'

data = os.popen(f"netstat -ano| findstr {HOST}:{PORT}").read()
try:
    process = data.split("\n")[0].split("LISTENING")[1].replace(" ", "")
    result = os.popen(f"taskkill /f -pid {process}").read()
    print(result)
except:pass
run(server='tornado', host=HOST, port=PORT, reloader=True)

