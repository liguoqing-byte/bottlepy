from global_conf.settings import *
from sqlalchemy import Column, String

'''
In order to achieve an optimized reorganization of the table structure, 
this file deletes and modifies the original table fields without harming the crude oil data.
'''


def add_column(engine, table_name, column):
    column_name = column.compile(dialect=engine.dialect)
    column_type = column.type.compile(engine.dialect)
    engine.execute('ALTER TABLE %s ADD COLUMN %s %s;' % (table_name, column_name, column_type))


def del_column(engine, table_name, column_name):
    engine.execute(f'alter table {table_name } drop  column {column_name};')


if __name__ == '__main__':
    while True:
        print('1、Add table field\n2、Delete table field')
        choose = int(input('please choose：'))
        if choose == 1:
            table_name = input('Please enter the table name：')
            column_name = input('Please enter the new column name：')
            # Please modify the following field statements before adding columns to meet your project field requirements
            column = Column(column_name, String(100))
            add_column(engine, table_name, column)
        else:
            table_name = input('please enter the table name：')
            column_name = input('Please enter the name of the column to be deleted：')
            del_column(engine, table_name, column_name)