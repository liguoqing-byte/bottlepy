from settings import *
import sys
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(BASE_DIR)
from apps.model import *
Base.metadata.create_all(engine)