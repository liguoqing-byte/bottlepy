# from bottle_sqlalchemy import sessionmaker
from bottle_sqlalchemy import SQLAlchemyPlugin
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import create_engine
from bottle_plus import bottle_plus
import bottle_session
import bottle_redis
import redis

app = bottle.app()


def db_config():
    DATABASES = {
        'ENGINE': 'mysqlconnector',
        'USER': 'root',
        'PASSWORD': 'root',
        'NAME': 'xqfj',
        'HOST': '127.0.0.1',
        }
    return 'mysql+{}://{}:{}@{}/{}?charset=utf8mb4&autocommit=true'.format(DATABASES['ENGINE'], DATABASES['USER'], DATABASES['PASSWORD'], DATABASES['HOST'], DATABASES['NAME'],)


Base = declarative_base()
engine = create_engine(db_config(), echo=True, pool_size=100, pool_recycle=3600)
# Session = sessionmaker(autocommit=False, autoflush=False, bind=engine)
# db = Session()

mysql_plugin = SQLAlchemyPlugin(engine, Base.metadata, keyword='db', create=False, commit=True, use_kwargs=False, create_session=None)
app.install(mysql_plugin)
try:
    Session = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db = Session()
except:
    db.rollback()
    db.expire_all()
    engine.dispose()
    Session = sessionmaker(autocommit=False, autoflush=False, bind=engine, expire_on_commit=True)
    db = Session()

# 设置session回话管理模块
'''
If you want to use this model, you can follow these steps in view.py， or you can not allow this model.

@route('/')
def test(session, rdb):
    rdb.incr('visitors')
    visitor_num = rdb.get('visitors')
    # when cookie_lifetime=10, last_visit_time will be None
    last_visit_time = session['visit']
    session['visit'] = datetime.now().isoformat()
    # first time when you login this website, you can setting a dict like follwing
    session['name'] = '我爱你'
    name = session.get('name')
    return '<p>{},{},{}</p>'.format(visitor_num, last_visit_time, name)
'''


session_plugin = bottle_session.SessionPlugin(cookie_lifetime=10)
redis_plugin = bottle_redis.RedisPlugin()
connection_pool = redis.ConnectionPool(host='127.0.0.1', port=6379)
session_plugin.connection_pool = connection_pool
redis_plugin.redisdb = connection_pool
app.install(session_plugin)
app.install(redis_plugin)


